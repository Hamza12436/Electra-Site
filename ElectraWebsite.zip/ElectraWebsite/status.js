const statusData = {
  executorStatus: {
    status: "Operational",
    uptime: 99.995,
    color: "#4caf50",
    version: "", 
  },
  robloxVersion: {
    status: "Up-to-date",
    uptime: 99.992,
    color: "#4caf50",
    version: "",
  },
  futureRobloxVersion: {
    status: "Pending",
    uptime: 75,
    color: "#ffa000",
  },
  robloxStatus: {
    status: "Service Disruption",
    uptime: 60,
    color: "#f44336",
  },
};

async function fetchExecutorVersion() {
  const versionUrl =
    "https://raw.githubusercontent.com/AwokenYT/electra-website/main/electra_version.txt";
  const corsProxy = "https://api.allorigins.win/raw?url=";
  const url = corsProxy + versionUrl;
  try {
    const response = await fetch(url);
    const data = await response.text();
    return data.trim();
  } catch (error) {
    console.error("Error fetching executor version:", error);
    document.getElementById("executor-version-text").textContent =
      "Error fetching version";
  }
}
async function fetchRobloxVersion() {
  const versionUrl =
    "https://clientsettings.roblox.com/v2/client-version/WindowsPlayer/channel/LIVE";
  const corsProxy = "https://api.allorigins.win/raw?url=";
  const url = corsProxy + versionUrl;

  try {
    const response = await fetch(url);
    const data = await response.json();
    const version = data.clientVersionUpload;

    document.getElementById("roblox-version-text").textContent = `${version}`;
    return version;
  } catch (error) {
    console.error("Error fetching Roblox version:", error);
    document.getElementById("roblox-version-text").textContent =
      "Error fetching version";
  }
}
async function fetchFutureRobloxVersion() {
  const versionUrl = "https://setup.rbxcdn.com/version";
  const corsProxy = "https://api.allorigins.win/raw?url=";
  const url = corsProxy + versionUrl;

  try {
    const response = await fetch(url);
    const data = await response.text();
    const version = data;

    document.getElementById(
      "future-roblox-version-text"
    ).textContent = `${version}`;
  } catch (error) {
    console.error("Error fetching Roblox version:", error);
    document.getElementById("future-roblox-version-text").textContent =
      "Error fetching version";
  }
}
fetchFutureRobloxVersion();

function calculateUptimePercentage(totalTime, downtimePeriods) {
  const totalDowntime = calculateDowntime(downtimePeriods);
  const uptimePercentage = ((totalTime - totalDowntime) / totalTime) * 100;
  return uptimePercentage.toFixed(2); 
}

function calculateDowntime(downtimePeriods) {
  let totalDowntime = 0;

  downtimePeriods.forEach((period) => {
    const start = new Date(period.start);
    const end = new Date(period.end);
    const downtime = (end - start) / (1000 * 60 * 60);
    totalDowntime += downtime;
  });

  return totalDowntime;
}

async function updateStatus() {
  // Update Roblox Version
  const [robloxVersion, executorVersion] = await Promise.all([
    fetchRobloxVersion(),
    fetchExecutorVersion(),
  ]);
  statusData.executorStatus.version = executorVersion;
  statusData.robloxVersion.version = robloxVersion;

  // Update Executor Status
  const executorStatusText = document.getElementById("executor-status-text");
  const executorProgress = document.getElementById("executor-progress");

  const executorData = statusData.executorStatus;
  executorStatusText.textContent = `${executorData.status}`;
  executorProgress.style.width = `${executorData.uptime}%`;
  executorProgress.style.backgroundColor = executorData.color;

  // Compare Versions
  const robloxData = statusData.robloxVersion;
  console.log("Updated Roblox version:", robloxData.version);
  const isVersionUpdated = executorData.version === robloxData.version;
  console.log(`Executer Version: ${executorData.version}`);
  console.log("Version comparison:", executorData.version, isVersionUpdated);

  if (!isVersionUpdated) {
    executorStatusText.textContent = `❌ Not Updated`;
  } else {
    executorStatusText.textContent = `✅ Updated`;
  }
}
document.addEventListener("DOMContentLoaded", updateStatus);

function applyStaggeredAnimation() {
    const statusBoxes = document.querySelectorAll('.status-box');
    statusBoxes.forEach((box, index) => {
        box.classList.add('staggered');

        box.style.animationDelay = `${index * 0.2}s`;
    });
}


document.addEventListener('DOMContentLoaded', async () => {
    await updateStatus();
    applyStaggeredAnimation();
});


document.addEventListener('DOMContentLoaded', () => {
    const homeButton = document.getElementById('home-button');
    homeButton.addEventListener('click', () => {
        window.location.href = 'index.html';
    });
});