document.addEventListener('DOMContentLoaded', function() {
    const adContainerWrapper = document.getElementById('ad-container-wrapper');
    const adCount = 4;

    for (let i = 0; i < adCount; i++) {
        const ad = document.createElement('div');
        ad.classList.add('ad-container');
        ad.classList.add(i === 0 ? 'ad-left' : 'ad-right'); 
        ad.textContent = `Ad ${i + 1}`;

        const closeButton = document.createElement('button');
        closeButton.classList.add('ad-close-button');
        closeButton.addEventListener('click', function() {
            ad.style.display = 'none';
        });

        ad.appendChild(closeButton);
        adContainerWrapper.appendChild(ad);
    }
});
